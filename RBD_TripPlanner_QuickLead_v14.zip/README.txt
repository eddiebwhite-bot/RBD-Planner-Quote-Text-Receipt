RBD Trip Planner — Quick Lead Integration (v14)
- index.html with Quick Lead button + modal
- netlify/functions/lead.js (admin email; zero-dep SMTP)
- netlify/functions/notify.js (AT&T SMS via email; zero-dep SMTP)
Set env vars in Netlify:
  SMTP_HOST  SMTP_PORT=465  SMTP_USER  SMTP_PASS  FROM_EMAIL  ADMIN_EMAIL
(Optional) GAS_WEBHOOK_URL