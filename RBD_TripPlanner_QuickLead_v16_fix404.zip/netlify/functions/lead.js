// netlify/functions/lead.js
import tls from "tls";
function b64(s){ return Buffer.from(String(s),"utf8").toString("base64"); }
function cram(s){ return s.replace(/\r?\n/g,"\r\n").replace(/\n/g,"\r\n"); }
function dotStuff(body){ return body.replace(/\n\./g,"\n.."); }
async function smtpSend({host, port=465, user, pass, from, to, subject, text}){
  return await new Promise((resolve, reject) => {
    const sock = tls.connect(port, host, { servername: host });
    sock.setEncoding("utf8");
    let buf="", step=0, closed=false;
    const send = l => sock.write(l+"\r\n");
    const die = e => { if(!closed){ closed=true; try{sock.end()}catch(_){ } ; reject(e);} };
    const done = () => { if(!closed){ closed=true; try{send("QUIT"); sock.end()}catch(_){ } ; resolve(true);} };
    sock.on("error", die);
    sock.on("data", (chunk) => {
      buf += chunk;
      while (buf.includes("\n")){
        const i = buf.indexOf("\n");
        const raw = buf.slice(0,i).replace(/\r$/,"");
        buf = buf.slice(i+1);
        const code = parseInt(raw.slice(0,3),10);
        const cont = raw[3]==="-";
        if (cont) continue;
        try{
          if (step===0){ if(code!==220) return die(new Error("SMTP greet: "+raw)); send("EHLO appriverbridgedelivery.netlify.app"); step=1; }
          else if (step===1){ if(code!==250) return die(new Error("EHLO: "+raw)); send("AUTH LOGIN"); step=2; }
          else if (step===2){ if(code!==334) return die(new Error("AUTH user: "+raw)); send(b64(user)); step=3; }
          else if (step===3){ if(code!==334) return die(new Error("AUTH pass: "+raw)); send(b64(pass)); step=4; }
          else if (step===4){ if(code!==235) return die(new Error("AUTH failed: "+raw)); send("MAIL FROM:<"+from+">"); step=5; }
          else if (step===5){ if(code!==250) return die(new Error("MAIL FROM: "+raw)); send("RCPT TO:<"+to+">"); step=6; }
          else if (step===6){ if(code!==250) return die(new Error("RCPT TO: "+raw)); send("DATA"); step=7; }
          else if (step===7){ if(code!==354) return die(new Error("DATA: "+raw));
            const hdrs = ["From: "+from,"To: "+to,"Subject: "+(subject||"RBD Quick Lead"),"MIME-Version: 1.0","Content-Type: text/plain; charset=utf-8"].join("\r\n");
            const body = dotStuff(cram("\r\n"+(text||"")));
            sock.write(hdrs+"\r\n\r\n"+body+"\r\n.\r\n"); step=8; }
          else if (step===8){ if(code!==250) return die(new Error("Queue: "+raw)); done(); }
        }catch(e){ die(e); }
      }
    });
  });
}
export default async (req)=>{
  try{
    if (req.method !== "POST") return new Response("Method Not Allowed", {status:405});
    const data = await req.json();
    const lines = [
      "New Quick Lead",
      `Name: ${data.name||""}`,
      `Phone: ${data.phone||""}`,
      `Pickup: ${data.pickup||""}`,
      `Drop: ${data.drop||""}`,
      `Service: ${data.service||"standard"}${data.trailer?" + Trailer":""}${data.rush?" + Rush":""}`,
      `Notes: ${data.notes||""}`,
      `Submitted: ${data.submittedAt||new Date().toISOString()}`
    ];
    const host=process.env.SMTP_HOST, port=Number(process.env.SMTP_PORT||465), user=process.env.SMTP_USER, pass=process.env.SMTP_PASS, from=(process.env.FROM_EMAIL||user), admin=(process.env.ADMIN_EMAIL||user);
    if(!host||!user||!pass) return new Response("SMTP env vars missing", {status:500});
    await smtpSend({host,port,user,pass,from,to:admin,subject:"RBD Quick Lead",text:lines.join("\n")});
    if (process.env.GAS_WEBHOOK_URL){
      try{ await fetch(process.env.GAS_WEBHOOK_URL,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(data)});}catch(_){}
    }
    return new Response(JSON.stringify({ok:true}), {status:200, headers:{"Content-Type":"application/json"}});
  }catch(e){ return new Response(String(e&&e.message||e), {status:500}); }
};
